window.onload = function() {
    
    introducePage();
}

function introducePage() {

    var cnt = 0;

    document.getElementById('firstForm').addEventListener('click', (e) => {
        e.preventDefault();
        var name = e.target.getAttribute('name');
        console.log('name : ' + name);
        fetchFunc(name);
    });
    document.getElementById('secondForm').addEventListener('click', (e) => {
        e.preventDefault();
        var name = e.target.getAttribute('name');
        console.log('name : ' + name);
        fetchFunc(name);
        
    });
    document.getElementById('thirdForm').addEventListener('click', (e) => {
        e.preventDefault();
        var name = e.target.getAttribute('name');
        console.log('name : ' + name);
        fetchFunc(name);
    });
    document.getElementById('fourthForm').addEventListener('click', (e) => {
        e.preventDefault();
        var name = e.target.getAttribute('name');
        console.log('name : ' + name);
        fetchFunc(name);
    });
    document.getElementById('fifthForm').addEventListener('click', (e) => {
        e.preventDefault();
        var name = e.target.getAttribute('name');
        console.log('name : ' + name);
        fetchFunc(name);
    });

    function fetchFunc(name) {
        console.log('name : ' + name);
        
        fetch('/introduce/' + name, {method: 'GET'})
            .then((response) => {
                console.log( response + 'asdadad');
                if(response.status == 200) {
                    console.log('받음?');
                    return response.json();
                }
            })
            .then((result) => {
                console.log('result is ', result);
                
                cnt++;

                //테스트용 태그
                /* var testH1 = document.createElement('h1');
                var testDiv = document.getElementById('testDiv');                
                var h1Test = document.createElement('h1');
                var divForH1 = document.createElement('div'); */

                //db값에서 불러온 값 저장할 공간 생성
                var name = document.createElement('h1');
                var birth = document.createElement('h1');
                var phone = document.createElement('h1');
                var email = document.createElement('h1');
                var myIntroduce = document.createElement('h1');
                
                //label 끼울 div
                var introduceDiv = document.createElement('div');        
                
                //db값 불러와서 각 label에 저장
                name.innerHTML = result.i_name;
                birth.innerHTML = result.i_birth;
                phone.innerHTML = result.i_phone;
                email.innerHTML = result.i_email;
                myIntroduce.innerHTML = result.introduce;
        
                                
                //값 넣기 전에 초기화
                introduceDiv.innerHTML = '';
                //div에 label값 저장
                introduceDiv.appendChild(name);
                introduceDiv.appendChild(birth);
                introduceDiv.appendChild(phone);
                introduceDiv.appendChild(email);
                introduceDiv.appendChild(myIntroduce);

                // /introduce/~~~~
                const members = ['memberone', 'membertwo', 'memberthree', 'memberfour', 'memberfive'];
                // 이미지 파일 경로
                const imageSourcePath = '/images/';
                const imageExtension = '.jpg';

                //이미지 태그
                var images = document.getElementsByClassName('members');
                //
                var profileDiv = document.getElementById('profile');

                //테스트 설정
                /* h1Test.innerHTML = '테스트';
                divForH1.style.display = 'inline-block'; */

                for(var i = 0; i < members.length ; i++) {
                    console.log(i + '번 멤버 : ' +members[i]);
                    //홀수는 멤버 한명만 포인트
                    if(cnt % 2 == 1) {
                        console.log('홀수 카운팅 : ' + cnt);

                        //display값을 inline-block으로 줘서 그림 옆에도 글을 쓸수 있도록 처리
                        profileDiv.style.display = 'inline-block';
                        
                        //db에서 가져온 값과 url /introduce/이후의 값이 일치하지 않은 멤버 사진 지움
                        if(result.i_name != members[i] && result.i_name != null) {
                            images[i].src = '';
                            images[i].style.marginRight = '0px';
                            
                        }
                        //db에서 가져온 값과 url /introduce/이후의 값이 일치하면 실행
                        if(result.i_name == members[i]) {
                            // testH1.innerHTML = '멤버 ' + (i + 1);
                            profileDiv.appendChild(introduceDiv);
                            /* testDiv.innerHTML = '';
                            divForH1.innerHTML = '';

                            divForH1.appendChild(h1Test);
                            testDiv.appendChild(testH1);       */                  
                        }
                        // console.log('margin value : ' + profileForm[i].style);
                        //짝수는 멤버 전체 포인트
                    } else if (cnt % 2 == 0) {
                        console.log('짝수 카운팅 : ' + cnt);
                        console.log('경로 : ' + images[i].src + '');

                        //이미지 경로 재설정
                        images[i].src = imageSourcePath + members[i] + imageExtension;        
                        images[i].style.marginRight = '30px';

                        //div의 display를 flex형태로 바꿔 재정렬
                        profileDiv.style.display = 'flex';

                        //값 초기화해서 값을 비움
                        // introduceDiv.remove();

                        console.log(introduceDiv + '');
                       /*  divForH1.innerHTML = '';
                        testDiv.innerHTML = ''; */
                    }
                }
                
            })
            .catch((err) => {
                console.error(err);
            });
    }
}
