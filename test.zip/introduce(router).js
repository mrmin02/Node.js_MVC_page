const express = require('express');
const { isLoggedIn ,isNotLoggedIn } = require('./middlewares');
const { User, Introduce } = require('../models');

const router = express.Router();

router.get('/', (req, res, next) => {
    console.log('조원 소개 페이지');
    User.findAll({})
        .then((members) => {
            console.log('데이터 넘겨줌');
            res.json(members);
        })
        .catch((err) => {
            console.error(err);
            next(err);
        });
});

router.get('/:id', (req, res, next) => {
    console.log('요청 받아짐');
    Introduce.findOne({where: {i_name: req.params.id}})
        .then((introduce) => {
            console.log('넘긴다.');
            console.log('req.params.id : ' + req.params.id );
            res.json(introduce);
            res.status(200);
            
        })
        .catch((err) => {
            console.error(err);
            next(err);
        });
    /* Introduce.findAll({})
        .then((introduce) => {
            console.log('introduce : ', introduce);
            res.json(introduce);
            res.status(200);
        })
        .catch((err) => {
            console.error(err);
            next(err);
        }); */
});

module.exports = router;